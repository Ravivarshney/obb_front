export class Obb{

     id:number
 	 userid:string
     userpassword:string
     username:string
     b_donor:string
     b_group:string
     date:string
     canDonate:string
     
}