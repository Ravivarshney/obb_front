import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Obb } from '../obb';
import { ObbService } from '../obb.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  obbs:Obb[];
  customerId:string
    constructor(private service : ObbService,private router : Router,private route : ActivatedRoute) { }
  
    ngOnInit(){
       this.customerId=sessionStorage.getItem('custId');
       this.customerId=this.route.snapshot.paramMap.get('custId')
  
  alert(this.customerId)
      this.service.getAll().subscribe(data=>this.obbs=data);
      
    }
  
  }
  